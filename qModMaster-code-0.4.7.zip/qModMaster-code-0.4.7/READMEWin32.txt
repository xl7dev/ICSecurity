
libmodbus - config.h
--------------------
#define HAVE_DECL_TIOCSRS485 0
#define HAVE_DECL_TIOCM_RTS 0
